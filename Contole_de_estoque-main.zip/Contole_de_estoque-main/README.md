# Projeto Beta Controle de Estoque

## Projeto criado e utilizando  o GitHub e GitHub Descktop

## Desenvolvido por Vellosodev.
## Ferramenta de Desenvolvimento: Visual Studio.
## Linguagem de Programação: Python.
## Biblioteca: Tkinter.

# Version: 1.0 

# Projeto para contorole de estoque, pode ser utilizado em varios ramos 