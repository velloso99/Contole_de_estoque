from tkinter.ttk import*
from tkinter import*
import tkinter as Tk
from tkinter import ttk
from tkinter import messagebox, Toplevel, END
from views import*
import os
from pathlib import Path
import requests
#Importando Pillow
from PIL import Image, ImageTk
#from tkinter import filedialog as fd
import subprocess
import tkinter as tk
from tkinter import Menu
from tkinter import StringVar
import locale
import time
import progressbar
#importando cores
from colors import*
# importando views
from views import*
#importando db
from sqlite3 import*
#tk calendario
from tkcalendar import Calendar, DateEntry
from datetime import date
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import datetime
import zipfile
import sys
import zipfile
import os
import shutil
from pathlib import Path
import requests
import shutil
from packaging import version  # Para comparar versões corretamente
import json