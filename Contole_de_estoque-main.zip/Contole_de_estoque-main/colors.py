co0 = "#e5e5e5"  # grey
co1 = "#2e2d2b"  # Preta
co2 = "#feffff"  # Branca 
co3 = "#1E90FF"  #DodgerBlue
co4 = "#FFFAFA"  #Snow
co5 = "#32CD32"  #LimeGreen
co6 = "#FFFF00" #Yellow


